# Nginx Helm Chart

A simple Helm chart for deploying Nginx on Kubernetes.

## TL;DR

```bash
$ helm install my-release ./nginx
```

## Introduction

This chart bootstraps a Nginx deployment on a Kubernetes cluster using the Helm package manager.

## Prerequisites

- Kubernetes 1.19+
- Helm 3.2.0+

## Installing the Chart

To install the chart with the release name `my-release`:

```bash
$ helm install my-release ./nginx
```

The command deploys Nginx on the Kubernetes cluster in the default configuration. The [Parameters](#parameters) section lists the parameters that can be configured during installation.

## Uninstalling the Chart

To uninstall/delete the `my-release` deployment:

```bash
$ helm delete my-release
```

## Parameters

### Image parameters

| Name                | Description                                          | Value           |
|---------------------|------------------------------------------------------|-----------------|
| `image.repository`  | Nginx image repository                               | `nginx`         |
| `image.tag`         | Nginx image tag                                      | `1.25.3`        |
| `image.pullPolicy`  | Nginx image pull policy                              | `IfNotPresent`  |

### Service parameters

| Name                | Description                                          | Value           |
|---------------------|------------------------------------------------------|-----------------|
| `service.type`      | Kubernetes Service type                              | `ClusterIP`     |
| `service.port`      | Service HTTP port                                    | `80`            |
| `service.targetPort`| Service target port                                  | `80`            |

### Ingress parameters

| Name                         | Description                                                | Value                    |
|------------------------------|------------------------------------------------------------|--------------------------|
| `ingress.enabled`            | Enable ingress controller resource                         | `false`                  |
| `ingress.className`          | IngressClass that will be be used                          | `""`                     |
| `ingress.annotations`        | Additional annotations for the Ingress resource            | `{}`                     |
| `ingress.hosts[0].host`      | Default host for the ingress resource                      | `chart-example.local`    |
| `ingress.hosts[0].paths[0].path` | Default path for the ingress resource                  | `/`                      |
| `ingress.hosts[0].paths[0].pathType` | Ingress path type                                  | `ImplementationSpecific` |
| `ingress.tls`                | Create TLS Secret                                          | `[]`                     |

### Resource Management parameters

| Name                | Description                                          | Value                    |
|---------------------|------------------------------------------------------|--------------------------|
| `resources.limits`  | The resources limits for the Nginx container         | `{}`                     |
| `resources.requests`| The requested resources for the Nginx container      | `{}`                     |

## Example: Enabling Ingress with TLS

To enable Ingress with TLS, you can use a values file like this:

```yaml
ingress:
  enabled: true
  className: nginx
  annotations:
    kubernetes.io/ingress.class: nginx
    cert-manager.io/cluster-issuer: letsencrypt-prod
  hosts:
    - host: example.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - secretName: example-tls
      hosts:
        - example.com
```

Then install the chart with:

```bash
$ helm install my-release ./nginx -f values-ingress.yaml
```
